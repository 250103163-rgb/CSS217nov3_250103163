package task4;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CustomsDutyDecorator extends PricingDecorator {
    public CustomsDutyDecorator(PricingService wrapped) { super(wrapped); }

    @Override
    public double calculateTotal() {
        double subtotal = super.calculateTotal();
        // BigDecimal + HALF_UP avoids double rounding errors: 145 * 1.085 = 157.325 -> 157.33
        return BigDecimal.valueOf(subtotal)
                .multiply(BigDecimal.valueOf(1.085))
                .setScale(2, RoundingMode.HALF_UP)
                .doubleValue(); // 8.5% customs tax
    }

    @Override
    public String getReceiptBreakdown() {
        return super.getReceiptBreakdown() + " + [Customs Duty: 8.5%]";
    }
}
